package com.yash.cravings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CravingsApplicationTests {

	@Test
	void contextLoads() {
	}



}
