package com.yash.cravings.service;

public class AdminServiceImplTest {

}
