package com.yash.cravings.service;

import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.yash.cravings.repository.FoodCartRepository;



@ExtendWith(MockitoExtension.class)

public class FoodCartServiceImplTest {


	
}
